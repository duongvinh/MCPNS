// ====================================================================================================================
// Macropixel Collocated Position Search for Plenoptic 2.0 Video Coding
// Vinh Van Duong, duongvinh@skku.edu
// Sungkyunkwan University, Korea
// ====================================================================================================================

## Setting Up

We provide the excuatble files with our source code of our proposed method:


Method 1: (This is the main proposed method) 
	
MCPNS: A low-complexity version of our proposed method, which can be set up like following:
	
#define MCPNS                                   1 // 0: TZS method; 1: Our proposed MCPNS 
#define ENABLE_FAST_MCPS                   1  // Enable fast MCP search candidates 
#define ENABLE_MAX_NUMBER_MCPN       1  // Enable fast K-MCP neigboring search candidates 


Method 2:  (Optional)
	
MCPNS: A high-efficiency version of our proposed method, which can be set up like following:
	
#define MCPNS                                   1 // 0: TZS method; 1: Our proposed MCPNS 
#define ENABLE_FAST_MCPS                   0  // Enable fast MCP search candidates 
#define ENABLE_MAX_NUMBER_MCPN       1  // Enable fast K-MCP neigboring search candidates 



## Configuration files

In order the encoding each videos from different plenopic camera models, we will need to add the argument "MacropixelSize" (-MISize) into the configuration file.

The details settings of macropixel size can find in "MacropixelSize_Parameter.PNG" file.

We already attached an example of configuration file in "encoder_randomaccess_vtm.cfg". 




